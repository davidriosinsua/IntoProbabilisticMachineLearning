
data {
  int<lower=1> N;
  int<lower=1> K;
  int<lower=1> H;

  matrix[N, K] X;
  vector[N] y;
}

parameters {

  // Input -> hidden layer weights
  matrix[H, K] W;

  // Hidden-layer biases
  vector[H] b;

  // Hidden -> output weights
  vector[H] v;

  // Output bias
  real beta0;

  // Observation noise
  real<lower=0> sigma;
}

model {

  // --------------------------------------------------------
  // Priors
  // --------------------------------------------------------

  to_vector(W) ~ normal(0, 1);
  b ~ normal(0, 1);

  v ~ normal(0, 1);
  beta0 ~ normal(0, 1);

  sigma ~ exponential(1);

  // --------------------------------------------------------
  // Likelihood
  // --------------------------------------------------------

  for (i in 1:N) {

    vector[H] hidden;

    hidden = tanh(b + W * X[i]');

    y[i] ~ normal(beta0 + dot_product(v, hidden),
      sigma
    );
  }
}

generated quantities {

  vector[N] y_rep;

  for (i in 1:N) {

    vector[H] hidden;
    real mu;

    hidden = tanh(b + W * X[i]');
    mu = beta0 + dot_product(v, hidden);
   y_rep[i] = normal_rng(mu, sigma);
  }
}
