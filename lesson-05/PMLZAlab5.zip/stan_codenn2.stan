data {

  int<lower=1> N;
  int<lower=1> K;
  int<lower=2> C;

  int<lower=1> H1;
  int<lower=1> H2;

  matrix[N, K] X;

  int<lower=1, upper=C> y[N];
}

parameters {

  // ----------------------------------------------------------
  // Input -> Hidden Layer 1
  // ----------------------------------------------------------

  matrix[H1, K] W1;
  vector[H1] b1;

  // ----------------------------------------------------------
  // Hidden Layer 1 -> Hidden Layer 2
  // ----------------------------------------------------------

  matrix[H2, H1] W2;
  vector[H2] b2;

  // ----------------------------------------------------------
  // Hidden Layer 2 -> Output
  // ----------------------------------------------------------

  matrix[C, H2] W3;
  vector[C] b3;
}

model {

  // ----------------------------------------------------------
  // Priors
  // ----------------------------------------------------------

  to_vector(W1) ~ normal(0, 1);
  b1 ~ normal(0, 1);

  to_vector(W2) ~ normal(0, 1);
  b2 ~ normal(0, 1);

  to_vector(W3) ~ normal(0, 1);
  b3 ~ normal(0, 1);

  // ----------------------------------------------------------
  // Neural network likelihood
  // ----------------------------------------------------------

  for (i in 1:N) {

    vector[H1] hidden1;
    vector[H2] hidden2;
    vector[C] logits;

    // First hidden layer
    hidden1 =
      tanh(
        b1 + W1 * X[i]'
      );

    // Second hidden layer
    hidden2 =
      tanh(
        b2 + W2 * hidden1
      );

    // Output layer
    logits =
      b3 + W3 * hidden2;

    // Multiclass likelihood
    y[i] ~ categorical_logit(logits);
  }
}

generated quantities {

  // Posterior predictive class
  int y_rep[N];

  // Posterior probability of each class
  matrix[N, C] class_prob;

  for (i in 1:N) {

    vector[H1] hidden1;
    vector[H2] hidden2;
    vector[C] logits;
    vector[C] p;

    hidden1 =
      tanh(
        b1 + W1 * X[i]'
      );

    hidden2 =
      tanh(
        b2 + W2 * hidden1
      );

    logits =
      b3 + W3 * hidden2;

    p = softmax(logits);

    class_prob[i] = p';

    y_rep[i] = categorical_rng(p);
  }
}
